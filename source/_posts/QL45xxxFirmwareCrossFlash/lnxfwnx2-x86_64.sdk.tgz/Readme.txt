﻿
                                ==========
                                README.TXT
                                ==========
                              
             Marvell NetXtreme Firmware Upgrade Tool for Linux
                Copyright (c) 2005-2019 Marvell Semiconductor Inc.
                        All rights reserved.



Table of Contents
=================
    1. Introduction
    2. Requirements
    3. Installation
    4. Supported Operating Systems
    5. Command Usage
    6. Exit Codes
    7. Examples
    8. Known Limitations
    9. Third Party Software License


1. Introduction:
================

LnxQlgcUpg.sh is a non-interactive shell script which can be run from a 
Linux terminal. This script can ONLY be used to upgrade the firmware components 
and it does not require user intervention.
On executing LnxQlgcUpg.sh, it automatically extracts the SDK contents and
initiate the upgrade process. On completion it displays success or failure message
to indicate final result.

lnxfwnx2 is a console application which can be run from a Linux terminal.
The application supports both command-line as well as interactive mode to interact 
with the users.
When calling the utility from another process or when using the utility 
as a command line tool, the utility will take commands from user specified
parameters and return appropriate exit code to indicate the result. 

This module is dependent on device driver and TCL libraries for firmware access.


2. Requirements:
================

     1.  Driver Versions: 
        a). For E3 controller:
            bnx2 Linux driver version 1.4.41 or above.  
         
        b). For E4 controller:
            qed  Linux driver version 8.3.4.0 or above.
            qede Linux driver version 8.3.4.0 or above.  
            qede(inbox) Linux driver version 8.33.0.20 on RHEL7.6, RHEL8.0, SLES12.4, SLES15.1 and higher
            (Note: The 41xxx/45xxx QeD/QeDe Linux drivers need to be upgraded in order to run upgrade using LnxQlgcUpg.sh
	         Do not use the in-box 41xxx/45xxx QeD/QeDe drivers with the LnxQlgcUpg.sh)

        b). For E4-AHP controller:
            qed  Linux driver version 8.60.12.0 or above.
            qede Linux driver version 8.60.12.0 or above.  

         Please refer to README.TXT of the target driver for installation instruction. 

     2.  For v2.4.1 or later
         libncurses.so.5 and libtinfo.so.5 are needed.
         Please use 'ldd lnxfwnx2' to find the dependency of these libraries.

     3. PHY Firmware can be upgraded only if the corresponding INTERFACES ARE UP.
        Please use the following command to up the interface.
        #ifconfig p6p1 up                       p6p1 => is the interface that need to be made up / down
        #ifconfig p6p1 down

     4. For RHEL7.9, RHEL8.3, SLES15SP2 and later OSes and using inbox drivers, please use FwUpg tool v2.11.3 or above
		Earlier version of FwUpg tool will not launch on above mentioned OSes having inbox drivers.
	 
3. Installation:
================
     1.  Non-interactive upgrade : No installation required
         Files required for Non-interactive upgrade:
         1)  lnxfwnx2-{arch}.sdk.tgz - SDK Package
         2)  LnxQlgcUpg.sh           - Script file
         3)  Marvell provided MBI file
         Note: LnxQlgcUpg.sh requires MBI (multi-boot image) file to be present in same folder 
               as LnxQlgcUpg.sh script file.
     
     2.  Manual mode 
         To install lnxfwnx2 SDK package. 
         a.  On terminal execute cmd 'tar -zxvf lnxfwnx2-{arch}.sdk.tgz' to untar the 
             package. 
 
             The files included in the sdk package are:
             1)  lnxfwnx2                -  This upgrade utility program
             2)  libtcl8.6.8.so          -  Dependent TCL library 
             3)  Readme.txt              -  This file.
             4)  Release.txt             -  Release Notes
             5)  qlgc_pci.ids            -  PCI ID file for adapter identification

4. Supported Operating Systems:
===============================
   OS Name                       OS Type        Hardware Platform
   ------------------------   ------------     --------------------
   * Red Hat RHEL AS/ES 8.x       64-bit            x64
   * Red Hat RHEL AS/ES 7.x       64-bit            x64
   * Red Hat RHEL AS/ES 6.x       32-bit            x86
   * Red Hat RHEL AS/ES 6.x       64-bit            x64
   * Red Hat RHEL AS/ES 5.8       32-bit            x86
   * Red Hat RHEL AS/ES 5.8       64-bit            x64
   * Red Hat RHEL AS/ES 5.7       32-bit            x86
   * Red Hat RHEL AS/ES 5.7       64-bit            x64
   * Red Hat RHEL AS/ES 5.6       32-bit            x86
   * Red Hat RHEL AS/ES 5.6       64-bit            x64

   * Novell SLES 15 SP2/SP1       64-bit            x64
   * Novell SLES 12 SP4/SP3/SP1   64-bit            x64
   * Novell SLES 11 SP2/SP1       32-bit            x86
   * Novell SLES 11 SP2/SP1       64-bit            x64


5. Command Usage:
=================

5.a Non-interactive upgrade
---------------------
    After installation run the shell script.

     ./LnxQlgcUpg.sh
     
    The script identifies the supported Marvell Adapters and upgrades all the firmware 
    components on all applicable adapters in a system. 

5.b Manual mode
------------------------
Notes: 
       1) Some of the commands are not supported for E4 and E4-AHP controllers. 
       2) For more information, please refer to the section 4.a.1 to view the 
          list of unavailable commands for E4 and E4-AHP.
       
Usage:
------
    lnxfwnx2 provides both command-line and interactive mode to the user.
    
    lnxfwnx2 { -all | [ID | MAC] } [Commands]
    The '-all' option applies to 'upgrade', 'restorenvram', 'cfg' and
    'factory_defaults' commands only. 

    The 'ID/MAC' option is used to select the adapter for the command to apply.
    It can be omitted if there is only one adapter in the system.

    The ID/MAC is optional for 'help', 'version', and 'dev' commands, 
    but it is required for all other commands.

    1. When '-all' is specified, 'ID' or 'MAC' cannot be specified.
       Commands 'upgrade', 'restorenvram', cfg and factory_defaults will use 
       the device information in the image to apply to all NICs that match the
       same device information. 

    2. On Linux, 'ID' is the the interface name (i.e. ethX). 

    3. 'MAC' is the MAC address name of the NIC in the system. For example, 
       '00:10:18:00:11:99' is a valid MAC address from 'ifconfig' utility. 
       Use '001018001199' as an input parameter to select the NIC.

5.b.1. Available commands:
---------------------------------------------------------------------
The following is the list of commands for E3, E4 and E4-AHP controllers.
    
Command Name            : General Command Description                    :  Command Support/Availability                                                                     
----------------        ---------------------------------------------     ----------------------------------
                                                                          [E3]  [E4-OOB drv]  [E4-inbox drv] [E4-AHP OOB]
                                                                          -----  -----------   ------------   ---------
    help                : list of available commands                     : Yes       Yes          Yes            Yes
    q                   : exit the program                               : Yes       Yes          Yes            Yes
    log                 : log output to a file                           : Yes       Yes          Yes            Yes
    dev                 : select an adapter or List available adapters   : Yes       Yes          Yes            Yes
    dir                 : display file directory in NVRAM                : Yes       Yes           No            Yes
    crc                 : check/update NVRAM checksum                    : Yes       Yes           No            Yes
    prg                 : Program NVRAM with specified firmware image    : Yes        No           No             No
    dumpnvram           : save entire NVRAM content or MDUMP image       : Yes       Yes           No            Yes
                          to a specified file
    restorenvram        : restore entire NVRAM content from a file       : Yes        No           No             No
    version             : display version of this program                : Yes       Yes          Yes            Yes
    upgrade             : upgrades the firmware or bootcode              : Yes       Yes          Yes            Yes
    reset               : reset the selected NIC.                        : Yes       Yes          Yes            Yes
    -w                  : Enable/Disable WOL                             : Yes       Yes          Yes            Yes
    cfg                 : Configure NVRAM                                : Yes       Yes          Yes            Yes
    phy                 : Upgrade PHY firmware                           : Yes       Yes          Yes            Yes
    info                : Displays the general information               : Yes       Yes           No            Yes
    factory_defaults    : Restore NVM_CFG1 to factory default settings   : No        Yes          Yes            Yes
    update_cfg          : Update NVM_CFG and META firmware images        : No        Yes          Yes             No
    xml                 : export the firmware versions in xml file       : Yes       Yes          Yes            Yes
    vlant               : Creates an empty VLAN Table in NVRAM           : Yes        No           No             No
    
5.2. Command usage discription with options:
--------------------------------------------
      
    upgrade [-noreset] [-F] {-bc|-mba|-ipmi|-ump|-ncsi|-m_pn|-ib|-ib_ipv6|
        -ib_ipv4n6|-l2t|-mfw1|-mfw|-feb|-vpd|-ccm}
        [-c] [-p] {<new_image>} [<save_image>]
        This command upgrades the firmware or bootcode for
        the NetXtreme II controller.  The <new_image> specifies
        the name of the file that contains the appropriate image.
        The <save_image> specifies the name of the file to which the
        current NVRAM contents will be saved. 
        The <new_image> is a mandatory parameter, but the <save_image> is an optional parameter.
        The current NVRAM content will NOT be saved if the <save_image> is not specified.
        Use forwardslash instead of backslash when specifying file path.
        Alternatively you could also use two backslashes in the file path.
        Use file/directory paths without quotes/spaces.
        If the upgrade version is same or older than the version
        in NVRAM, upgrade will be aborted.
        The -noreset option is to skip the driver restart of the selected
        NIC after the firmware upgrade is completed.  This option is only
        valid in Command Line Mode.
        If there an error in upgrading any component of MBI image, upgrade process will be
        be aborted immediatly.
        The -F option is to force the upgrade without checking version.
            OPTION             NAME OF FIRMWARE OR BOOT IMAGE
            -bc                bootcode
            -mfw1              bootcode + NCSI firmware for BCM57712 and above
            -mfw               Upgrade MFW firmware
            -mba               MBA (PXE) code
            -l2t               L2 firmware for BCM5771x adapter
            -ipmi              IPMI management firmware
            -ump               UMP management firmware
            -ncsi              NCSI management firmware
            -m_pn              I/O module file for BCM5771x adapter
            -ib                iSCSI boot driver with IPv4 address support.
            -ib_ipv6           iSCSI boot driver with IPv6 address support.
            -ib_ipv4n6         iSCSI boot driver with IPv4 and IPv6 address support.
            -feb               FCoE boot code.
            -vpd               Extended VPD.
            -ccm               CCM firmware.
            -mbi               Monolithic Image.
        The [-c], [-p] option is valid only when "-ib/-ib_ipv6/-ib_ipv4n6" option is specified.
        The [-c] option is also valid when "-feb" option is specified.
            -c                 upgrade the iSCSI/FCoE configuration along with
                               iSCSI/FCoE boot code.
                               The '-ib', '-ib_ipv6', and '-ib_ipv4n6' will add/
                               upgrade the iSCSI configuration automatically.
                               The '-feb' will add/upgrade the FCoE configuration
                               automatically.  This option is obsolete and no longer
                               necessary.
                               This option does not have effect any more.
            -p                 upgrade the iSCSI configuration program along
                               with iSCSI boot code.  This option is obsolete and
                               no longer necessary.
        Note:
            For E4 controller, the ONLY availabe options are -mba, -mfw, -mbi.

    reset
        Reset the selected NIC.  This command is only valid in Command Line Mode.

    -w {<value>}
        The function enables or disables WOL setting.
        <value> set to '1' to enable WOL.
        <value> set to '0' to disable WOL.

    restorenvram {<filename>} [idmatch] [lic] [config [mac]] [preserve [vpd]]
        This command reads complete NVRAM image from a file and
        writes the image to NVRAM.
        Before writing the NVRAM image to adapter, verifications
        against source NVRAM image will be performed. If any verification
        failed, the image will not be written to adapter.
        <filename> is the file name of NVRAM image.
        <filename> is a mandatory parameter. Use forwardslash instead of 
        backslash when specifying <filename>. Alternatively you could also 
        use two backslashes in the file path. Use file/directory paths 
        without quotes/spaces.
        'idmatch' requests the Firmware Upgrade Tool to restore the NVRAM
        image only if the 4 IDs (vendor_id, device_id, subsystem_vendor_id,
        subsystem_device_id) in the image file match those in the device.
        'lic' means licencing information will be copied from 
        the source image, without this parameter it's preserved.
        'config' means configuration area will copy from source
        image except MAC address.
        Configuration area includes MAC address and various
        options.
        'mac' applies only when 'config' is specified.
        When 'mac' is specified, all configuration are copied
        including MAC address.
        'preserve' means all other components will be copied from
        the source image except for the parameters supplied\r\n"
        after this command.
        'vpd' is applicable with 'preserve' option.  When 'vpd' is
        specified, vpd information of nvram is preserved.

    dumpnvram {<filename>}
        Dumps the NVRAM contents or MDUMP image to the specified file.
        if "mdump" option is not specified then dump the entire NVMRAM contents 
        to specified file.
        <filename> is a mandatory parameter. Use forwardslash instead of 
        backslash when specifying <filename>. Alternatively you could also 
        use two backslashes in the file path. Use file/directory paths 
        without quotes/spaces.

    prg {-ib|-ib_ipv6|-ib_ipv4n6|-mba|-ccm} {<new_image>} [-c] [-p]
        This command programs NVRAM with the specified firmware image.
        -ib        : iSCSI boot driver with IPv4 address support.
        -ib_ipv6   : iSCSI boot driver with IPv6 address support.
        -ib_ipv4n6 : iSCSI boot driver with both IPv4 and IPv6 address support.
        -mba       : MBA firmware
        -ccm       : CCM firmware
        <new_image>: a mandatory parameter to specify the input binary file.
        -c         : force to program iSCSI configuration, only valid when
                     used with -ib, -ib_ipv6, or ip_ipv4n6 option.
        -p         : force to program iSCSI configuration utility program, only
                     valid when used with -ib, -ib_ipv6, or ip_ipv4n6 option.
        Note: 'prg' command only supports selective Marvell adapters.
              The image file for the 'prg {-ib|-ib_ipv6|-ib_ipv4n6}' command
              is required to contain ONLY valid iSCSI boot without other
              firmware directories.

    crc [-all] {-mbi} {mbi_file}
        Performs the CRC check to verify the integrity of the NVRAM.
        -all        : Performs CRC check on all the adapters present on the system.
        -mbi        : To selectively perform CRC check on selected adapters 
        <mbi_file>  : crc check will be performed on adapters supported by MBI and  
                      present on system. 
                      Above options are only available in cmd line mode.

    dir [-delete <entry>]
        Displays a listing of the firmware programmed in NVRAM.
        Delete the specified <entry> in the directory and its firmware from NVRAM.
        The <entry> can be found from 'Image' list using the 'dir' command.
        The user should use 'cfg' command to disable the management option before
        removing the management firmware.
        -all        : Displays listing of the firmware in NVRAM for all the adapters present on the system.
        -mbi        : To display listing of the firmwares in NVRAM for selected adapters
        <mbi_file>  : dir will be performed on adapters supported by MBI and present on system. 
                      Above options are only available in cmd line mode.        

    dev [<number>]
        <number> is the adapter to be selected as target device

    cfg [-noreset] {-mac <MAC address to be programmed for current selected device> | 
	     -lldpmac <LLDP MAC address to be programmed for current selected port> | 
         -mba <value> | -ipmi <value> | -ump <value> | -wol <value> | -2p5g <value> |
         -mgmt <value> | -dcbx <value> | -shadow_swim <value> |
         -sriov_hide_menu <value> | -sriov <value> | -revid_ctl <value> |
         -vf_per_pf <value> | -vpdv0 <version string> | -bar2size | -show [show_option]}
        This command programs the specified configuration into NVRAM.
        The -ipmi, -ump, and -mgmt are used to enable/disable the
        management firmware which can be one of ipmi, ump, or ncsi.
        Both "-ipmi" and "-ump" are deprecated in favor of the "-mgmt".
        The user should not enable MGMT option in the absence of the
        management firmware.

        The -noreset option is to skip the driver restart of the selected
        NIC after the 'cfg' operation is completed.  This option is only
        valid in Command Line Mode.

        -mac        : <MAC address for current selected device> is a 
                      12-digit HEX MAC address, e.g. 0010181a2b3c.
                      This option is valid for BCM57712 or later NICs.
        -lldpmac    : <LLDP MAC address for current selected port> is a 
                      12-digit HEX MAC address, e.g. 0010181a2b3c.
                      This option is valid for 579xx and QL4xxxx NICs.
        -mba        : set <value> to '1' to enable mba firmware.
                      set <value> to '0' to disable mba firmware.
                      This option is valid for BCM57712 and 578xx NICs.
        -ipmi       : set <value> to '1' to enable management firmware.
                      set <value> to '0' to disable management firmware.
                      This option is valid for BCM57712 NICs.
        -ump        : set <value> to '1' to enable management firmware.
                      set <value> to '0' to disable management firmware.
                      This option is valid for BCM57712 NICs.
        -mgmt       : set <value> to '1' to enable management firmware.
                      set <value> to '0' to disable management firmware.
                      This option is valid for BCM57712 NICs.
        -wol        : set <value> to '1' to enable wol feature.
                      set <value> to '0' to disable wol feature.
        -2p5g       : set <value> to '1' to enable 2.5G SERDES support.
                      set <value> to '0' to disable 2.5G SERDES support.
                      This option is valid for BCM5706 NIC.
        -dcbx       : For BCM57712 and 578xx NICs:
                      set <value> to '1' to enable DCBX functionality.
                      set <value> to '0' to disable DCBX functionality.
                      For 579xx and QL4xxxx NICs:
                      set <value> to '0' to disable DCBX functionality.
                      set <value> to '1' to select IEEE mode.
                      set <value> to '2' to select CEE mode.
                      set <value> to '3' to select Dynamic mode.
        -shadow_swim: set <value> to '1' to enable Shadow SWIM functionality.
                      set <value> to '0' to disable Shadow SWIM functionality.
                      This option is valid for BCM57712 or 578xx.
        -sriov_hide_menu: set <value> to '1' to hide SRIOV menu.
                      set <value> to '0' to show SRIOV menu.
                      This option is valid for BCM57712 and 578xx NICs.
        -sriov      : set <value> to '1' to enable SRIOV.
                      set <value> to '0' to disable SRIOV.
                      This option is valid for BCM57712 or later NIC.
        -vf_per_pf  : set the number of VF per PF.
                      This option is valid for BCM57712 and 578xx NICs.
        -vpdv0      : set <version string> to VPD V0 tag.
                      <version string> should be in x.y.z format.
                      This option is valid for BCM57712 or later NIC.
        -revid_ctl  : set <value> to '0' to preserve revision Id.
                      set <value> to '1' for actual revision Id.
                      set <value> to '2' to force B0.
                      set <value> to '3' to force B1.
                      This option is valid for 578xx NIC.
        -rdma_enablement    : set <value> to '0' to disable RDMA.
                      set <value> to '1' to enable RoCE.
                      set <value> to '2' to enable iWarp.
                      set <value> to '3' to enable both RoCE and iWarp.
                      This option is valid for 579xx and QL4xxxx NICs.
        -roce_priority_mode : set <value> from '0' to '7' to set ROCE priority mode.
                      This option is valid for 579xx and QL4xxxx NICs.                     
        -mba_boot_protocol  : set <value> to '0' for PXE boot.
                      set <value> to '3' for iSCSI boot.
                      set <value> to '4' for FCoE boot.
                      set <value> to '7' for None.
                      This option is valid for 579xx and QL4xxxx NICs.
        -bar2size: set <value> as per following table:
                      For 579xx based adapters:
                      0 (Disabled), 1 (64K), 2 (128K), 3 (256K),
                      4 (512K), 5 (1M), 6 (2M), 7 (4M), 8 (8M), 9 (16M),
                      10 (32M), 11 (64M), 12 (128M), 13 (256M),
                      14(512M), 15(1G)
                      For QL4xxxx based adapters:
                      0 (Disabled), 5 (1M), 6 (2M), 7 (4M), 8 (8M),
                      9 (16M), 10 (32M), 11 (64M), 12 (128M),
                      13 (256M), 14 (512M), 15 (1G)\r\n"
                      This option is valid for 579xx and QL4xxxx NICs.
        -show       : show the settings of current configuration.
                      If 'show_option' is specified, it will show the
                      setting of the specified option, 
                      <show_option> 'sriov' will display whether SRIOV is enabled or disabled
                      <show_option> 'vf_per_pf' will display VF per PF setting
                      <show_option> 'manuf_kit_ver' will display manufacture kit version
                      <show_option> 'manuf_date' will display manufacture date

    phy {-ver | -upg <filename> }
        This command can display the firmware version of external PHY or
        upgrade the PHY firmware.  After upgrading the PHY firmware, a
        system reboot is required for the new PHY firmware to become
        effective.

    -w {<value>}
        The function enables or disables WOL setting.
        <value> set to '1' to enable WOL.
        <value> set to '0' to disable WOL.

    factory_defaults
        Reset the selected NIC NVM_CFG1 to factory defaults settings.  
        This command is only valid for E4 and E4-AHP adapters.
        Limitations of factory_defaults:
        - In the interactive mode even though factory_defaults is percieved to be executed on port
          basis but the changes will be reflected on all the ports.
        - The cmd can’t handle user changes on options which changed their type. E.g. if a user
          made a change on an option that was changed from per-port to per-function, then a new
          per-function option will be created in the new NVM_CFG1 (the pre-port option is obsolete). 
          The new per-function option will be set to its default value and not to the user’s change 
          value of the obsolete per-port option, since the tool can’t relate this option to the old 
          obsolete option.

    update_cfg [<nvm_cfg>.bin <meta>.txt]
        This command updates DEFAULT_CFG and NVM_CFG firmware in NVMRAM
        The command require both nvm_cfg image (in binary format) and meta image (in txt format)
        to update NVM_CFG and DEFAULT_CFG in NVRAM.
        This command is only valid for E4 adapters.
        - In the interactive mode even though update_cfg is perceived to be executed on port
          basis but the changes will be reflected on all the ports.
        - While upgrading NVM_CFG, the cmd automatically takes care of the options changed by the user.

    info
        This command displays the following general information. 
        
            Property Name     : Description/Comment
            -------------     ---------------------
            Temperature       : Displays temperature in Celsius for E3 and E4 adapters.
            Active SWIM       : Displays current active SWIM group for E3 adapters only.
    
    xml {xml_file_name} {mbi_file_name}
        This cmd will read the firmware versions either from NVRAM or MBI file and export to XML file
        -xml_file_name        : Name of the XML file to be created 
        -mbi_file_name        : IF valid MBI file is passed then firmware versions are read from MBI file and 
                                exported to XML ELSE firmware versions are read from NVRAM and exported to XML

    vlant {[-reset] [-delete]}
        If VLAN table is not present in NVRAM then this cmd will create an empty VLAN Table in NVRAM.
        This command is only available for E3 adapters.
        -reset                : clears all the entries in VLAN table  
        -delete               : deletes VLAN table from NVRAM 
        
6. Exit Codes:
==============

/////////////////////////////////////////////////////////////////////////
// Return codes
#define FWUPG_OK                                0   // Upgrade firmware OK
#define FWUPG_QUIT                              1   // Quit program
#define FWUPG_PARAM_ERROR                       2   // Not correct parameters
#define FWUPG_NOT_CORRECT_TARGET                3   // Not applicable to this device. 
#define FWUPG_CANNOT_READ_NVRAM                 4   // Cannot read NVRAM
#define FWUPG_FAILED_GET_NVRAM_SIZE             5   // Cannot get NVRAM size
#define FWUPG_CANNOT_GET_HANDLE                 6   // Cannot get NIC handle
#define FWUPG_ADAPTER_NOT_FOUND                 7   // Adapter not found
#define FWUPG_CANNOT_LOCK_ADAPTER               8   // Cannot lock adapter
#define FWUPG_FAILED_GET_PXE_INFO               9   // Failed to get PXE
                                                    // information
#define FWUPG_FAILED_CREATE_NVRAM_IMAGE_FILE    10  // Failed to create NVRAM
                                                    // image file
#define FWUPG_FAILED_WRITE_NVRAM_IMAGE_FILE     11  // Failed to write to
                                                    // NVRAM image file
#define FWUPG_GET_CLOSE_EVENT                   12  // Get close event
#define FWUPG_FAILED_READ_NVRAM_FILE            13  // Failed to read NVRAM
                                                    // image file
#define FWUPG_INIT_FAILED                       14  // Initialization failed
#define FWUPG_UNSUPPORTED_QLMAPI_VER            15  // QLMAPI is too old
#define FWUPG_NIC_NOT_SUPPORTED                 16  // NIC is not supported
#define FWUPG_UNKNOWN_COMMAND                   17  // Unknown command
#define FWUPG_NVRAM_WRITE_FAILED                18  // NVRAM update failed
#define FWUPG_WRONG_NVRAM_FILE_SIZE             19  // NVRAM image file size
#define FWUPG_NVRAM_IMAGE_CHKSUM_FAILED         20  // NVRAM image file
                                                    // checksum failed
#define FWUPG_NVRAM_CHKSUM_FAILED               21  // NVRAM crc or checksum failed
#define FWUPG_NVRAM_IMAGE_FILE_DEVID_MISMATCH   22  // device information or media 
                                                    // type in NVRAM image file
                                                    // does not match NIC
#define FWUPG_ASF_NOT_SUPPORTED_BY_BOOTCODE     23  // ASF is not supported by
                                                    // the bootcode firmware
#define FWUPG_ASF_NOT_SUPPORTED_BY_NIC          24  // ASF is not supported by
                                                    // the NIC hardware
#define FWUPG_DIR_FULL                          25  // No NVRAM directory entry
                                                    // available
#define FWUPG_INVALID_NVRAM_FILE                26  // Incorrect NVRAM file
                                                    // format
#define FWUPG_NVRAM_FULL                        27  // not enough NVRAM space
#define FWUPG_DIR_NOT_SUPPORTED                 28  // Directory is not
                                                    // supported by bootcode
#define FWUPG_NVRAM_CORRUPTED                   29  // NVRAM corrupted
#define FWUPG_DIR_NOT_FOUND                     30  // a directory entry is
                                                    // not found
#define FWUPG_DIR_UPDATE_FAILED                 31  // Update NVRAM directory
                                                    // failed
#define FWUPG_DIR_FOUND                         32  // a directory entry is
                                                    // found
#define FWUPG_CANNOT_READ_MEM                   33  // Cannot read NIC register
                                                    // or memory
#define FWUPG_MALLOC_ERROR                      34  // memory allocation error
#define FWUPG_FW_IMAGE_WRONG_VERSION            35  // wrong version of
                                                    // firmware image
#define FWUPG_FW_IMAGE_INVALID_ASF              36  // invalid asf image
#define FWUPG_READ_NIC_ASF_TABLE_FAILED         37  // failed to read ASF table
                                                    // from  NIC
#define FWUPG_UNSUPPORTED_NIC_ASF_TABLE         38  // version of ASF table on
                                                    // NIC is not supported
#define FWUPG_REBOOT_FAILED                     39  // unable to reboot machine
#define FWUPG_NOT_SUPPORTED_DRIVER              40  // the version of driver is
                                                    // too old
#define FWUPG_DRIVER_NOT_LOADED                 41  // driver is not loaded
#define FWUPG_FILE_TOO_BIG                      42  // file is too big
#define FWUPG_CANNOT_WRITE_MEM                  43  // Cannot write NIC
                                                    // register or memory
#define FWUPG_MGMT_FW_NOT_FOUND                 44  // Cannot find management 
                                                    // firmware
#define FWUPG_UMP_FOUND                         45  // UMP firmware exist
#define FWUPG_FAILED_TO_GET_VERINFO             46  // failed to get module
                                                    // version info
#define FWUPG_ERR_ENDOFFILE                     47  // unexpected end of file
                                                    // encountered.
#define FWUPG_INVALID_MEDIUM_TYPE               48  // The chip has an unknown
                                                    // medium type. Neither the
                                                    // board is copper nor
                                                    // serdes.
#define FWUPG_INVALID_OFFSET                    49  // invalid NVRAM offset.
#define FWUPG_FILE_ALREADY_EXISTS               50  // output file already
                                                    // exists.
#define FWUPG_NON_SELFBOOT_IMAGE                51  // Not a selfboot image.
#define FWUPG_BAD_MAGIC_VALUE                   52  // Bad magic value
#define FWUPG_BAD_PARITY_VALUE                  53  // Bad parity value
#define FWUPG_BAD_VPD_CHKSUM                    54  // Bad VPD checksum
#define FWUPG_BAD_CHIP_REV                      55  // Bad chip revision
#define FWUPG_VPD_DATA_MISSING                  56  // VPD data missing
#define FWUPG_NO_SELFBOOT                       57  // target not self boot 
                                                    // capable
#define FWUPG_LEGACY_TO_SELFBOOT                58  // Cannot upgrade firmware 
                                                    // from legacy to selfboot.
#define FWUPG_ZERO_SELFBOOT                     59  // upgfrm does not support 
                                                    // Format 0 Selfboot image 
                                                    // upgrade
#define FWUPG_UNSUPPORTED_FEATURE               60  // Feature not supported.
#define FWUPG_DIAG_FAILURE                      61  // diag failure
#define FWUPG_NO_BRCM_ADAPTER                   62  // No Marvell network 
                                                    // adapter found!
#define FWUPG_FILE_DOES_NOT_EXIST               63  // File does not exist
#define FWUPG_UMP_NOT_SUPPORTED                 64  // ump not supported
#define FWUPG_MISSING_UMP                       65  // UMP config firmware is
                                                    // not loaded in NVRAM
#define FWUPG_CFG_VER_MISMATCH                  66  // UMP config version 
                                                    // mismatch
#define FWUPG_INVALID_ISCSI_IMAGE               67  // invalid ISCSI image
#define FWUPG_INVALID_UMP_IMAGE                 68  // invalid UMP image
#define FWUPG_INVALID_MBA_IMAGE                 69  // invalid MBA image
#define FWUPG_PRG_FAILED                        70  // programming NVRAM failed
#define FWUPG_BOOTSTRAP_UPDATE_FAILED           71  // bootstrap update failed
#define FWUPG_CMD_ALL_NOT_SUPPORTED             72  // '-all' option is not 
                                                    // supported in this context
#define FWUPG_UNSUPPORTED_PLATFORM              73  // Feature not supported on 
                                                    // this platform
#define FWUPG_MAC_PARAM_ERROR                   74  // Cannot override MAC on 
                                                    // multiple NICs.
#define FWUPG_INVALID_BOOTCODE                  75  // Not a valid bootcode file
#define FWUPG_INVALID_IPMI_FILE                 76  // Not a valid ipmi file
#define FWUPG_INVALID_DUMP                      77  // Invalid dump file.
#define FWUPG_INVALID_FORMAT                    78  // Invalid image/file format.
#define FWUPG_DIR_ENTRY_MISMATCH                80  // Mismatch in directory entries
#define FWUPG_MBA_MISMATCH                      81  // MBA directory entry mismatch
#define FWUPG_UMP_MISMATCH                      82  // UMP directory entry mismatch
#define FWUPG_IPMI_MISMATCH                     83  // IPMI directory entry mismatch
#define FWUPG_ISCSI_MISMATCH                    84  // ISCSI directory entry mismatch
#define FWUPG_ASF_MISMATCH                      85  // ASF directory entry mismatch
#define FWUPG_ISCSI_NOT_SUPPORTED               86  // ISCSI is not supported.
#define FWUPG_SPECIAL_UPGRADE_REQUIRED          87  // Special upgrade is required.
#define FWUPG_MISSING_CMD                       88  // No valid command was specified.
#define FWUPG_RESERVE1                          89  // Reserved message holder.
#define FWUPG_RESERVE2                          90  // Reserved message holder.
#define FWUPG_MISSING_ASF                       91  // ASF config firmware is
                                                    // not loaded in NVRAM
#define FWUPG_MISSING_IPMI                      92  // IPMI config firmware is
                                                    // not loaded in NVRAM
#define FWUPG_MISSING_MBA                       93  // MBA config firmware is
                                                    // not loaded in NVRAM
#define FWUPG_NO_DEV_ID                         94  // No device ID in NVRAM image file
#define FWUPG_SYSTEM_REBOOT                     95  // System Reboot required
#define FWUPG_INVALID_NCSI_IMAGE                96  // invalid NCSI image
#define FWUPG_MISSING_MGMT_FW                   97  // Missing management firmware in NVRAM
#define FWUPG_INVALID_PHY_IMAGE                 98  // Invalid PHY firmware file.
#define FWUPG_DRIVER_COMMUNICATE_ERROR          99  // Error in communicating to driver
#define FWUPG_FW_EXISTING_IN_NVRAM              100 // The firmware to be programmed is existing in NVRAM
#define FWUPG_FAIL_TO_GET_MAC_ADDR              101 // Failed to read MAC ADDR from the file
#define FWUPG_MGMTFW_NOT_SUPPORTED_BY_NIC       102 // Management firmware is not supported by the NIC
#define FWUPG_IMAGE_FILE_CRC_ERROR              103 // Image file CRC error
#define FWUPG_IMAGE_FILE_SIG_ERROR              103 // Image file RSA signature error
#define FWUPG_INVALID_L2T_IMAGE                 104 // invalid L2T image
#define FWUPG_CMD_ABORTED                       105 // Command aborted
#define FWUPG_PHY_FW_CORRUPTED                  106 // PHY firmware corrupted
#define FWUPG_UNKNOWN_EXT_PHY                   107 // Unknown external PHY
#define FWUPG_CANNOT_UPGRADE_TO_DIFF_FORMAT     108 // Can't upgrade to a different format
#define FWUPG_CANNOT_READ_OTP                   109 // Can't read to OTP
#define FWUPG_CANNOT_WRITE_OTP                  110 // Can't write to OTP
#define FWUPG_FAIL_TO_CREATE_EXT_DIR_ENTRY      111 // Failed to create Extended Directory entry
#define FWUPG_INVALID_BOOTCODE_IMAGE            112 // invalid Bootcode image
#define FWUPG_INVALID_IO_MODULE_IMAGE           113 // Invalid I/O Module file.
#define FWUPG_NCSI_MISMATCH                     114 // NCSI directory entry mismatch
#define FWUPG_INVALID_FCOE_IMAGE                115 // Invalid FCoE image
#define FWUPG_FCOE_MISMATCH                     116 // FCOE directory entry mismatch
#define FWUPG_32BIT_APP_IN_WOW64                117 // Can't run 32-bit application in 64-bit platform.
#define FWUPG_IMAGE_FILE_SIG_ERROR              118 // Image file RSA signature error
#define FWUPG_32BIT_APP_IN_WOW64                119 // Can't run 32-bit application in 64-bit platform.
#define FWUPG_INVALID_MFW_IMAGE                 120 // Invalid MFW image
#define FWUPG_INVALID_CCM_IMAGE                 121 // invalid CCM image
#define FWUPG_CCM_NOT_SUPPORTED                 122 // CCM is not supported.
#define FWUPG_CCM_MISMATCH                      123 // CCM directory entry mismatch 
#define FWUPG_DIAG_TEST_NOT_SUPPORTED           124 // Specified Diagnostic tests are not supported 
#define FWUPG_DIAG_TEST_FAILED                  125 // Diagnostic test failed
#define FWUPG_INVALID_MBI_IMAGE                 126 // invalid MBI image
#define FWUPG_INVALID_MBI_LENGTH                127 // MBI length mismatch
#define FWUPG_REGISTER_TEST_FAILED              128 // Register test failed
#define FWUPG_MII_REGISTER_TEST_FAILED          129 // MII registers test failed
#define FWUPG_NVRAM_TEST_FAILED                 130 // NVRAM test failed
#define FWUPG_MEMORY_TEST_FAILED                131 // Memory test failed
#define FWUPG_TEST_INTERRUPT_FAILED             132 // Interrupt test failed
#define FWUPG_CPU_TEST_FAILED                   133 // CPU test failed
#define FWUPG_MAC_LOOPBACK_TEST_FAILED          134 // Loopback test failed
#define FWUPG_PHY_LOOPBACK_TEST_FAILED          135 // Loopback test failed
#define FWUPG_LED_TEST_FAILED                   136 // LED test failed
#define FWUPG_INVALID_HW_INIT_IMAGE             137 // Not a valid INIT_HW file
#define FWUPG_RESTORED_NIC_BACK_TO_NORMAl_STATE 138 // Restored the NIC back to normal state in the event of failed or partial MBI firware update or CRC checksum failed.
#define FWUPG_SHA256_AUTH_FAILED_ON_NVM_DUMP    139 // SHA256 authentication failed against nvm dump before restoring back to normal state.
#define FWUPG_RESTORE_FAILED                    140 // Failed to restore the NIC back to normal state.
#define FWUPG_FAILED_GET_CURRENT_TEMPERATURE    141 // Failed to get the current temperature of the NIC.
#define FWUPG_BLOCKED_AHALOM_FROM_CNA_TO_NIC    142 // Block MBI downgrade from CNA (HP12.10) to NIC (HP12.00) for HP ALOM adapters
#define FWUPG_META_PARSEING_ERROR               143 // Unable to parse META file
#define FWUPG_INVALID_OPTION                    144 // This option is not a valid option
#define FWUPG_UNSUPPORTED_OPTION                145 // This option is not available on this adapter
#define FWUPG_INVALID_OPTION_VALUE              146 // Supplied value for this NVM_CFG1 option is invalid
#define FWUPG_NO_DRVR_NVRAM_ACCESS              147 // On Linux platform only Firmware upgrade is supported with inbox driver, other NVM operations like dir,crc etc. are not supported.
#define FWUPG_READ_CONFIG_FAILED                148 // NVRAM read configuration failed.
#define FWUPG_DRIVER_NOT_INSTALLED              149 // Intermediate or miniport driver not installed.
#define FWUPG_READ_EEPROM_FAILED                150 // EPROM read failed.
#define FWUPG_WRITE_EEPROM_FAILED               151 // EPROM write failed.
#define FWUPG_NO_READ_EEPROM_PRIV               152 // No privilege to read EEPROM.
#define FWUPG_NO_WRITE_EEPROM_PRIV              153 // No privilege to read EEPROM.
#define FWUPG_NO_DIAG_ACCESS_RIGHT              154 // Application did not call QLmapiInitDiag() with successful return.
#define FWUPG_DATA_NOT_FOUND                    155 // Requested data not found.
#define FWUPG_READ_REGISTER_FAILED              156 // read register failed.
#define FWUPG_UNSUPPORTED_IOCTL                 157 // unsupported IOCTL.
#define FWUPG_DEVIO_CALL_FAILED                 158 // DeviceIoControl() failed.
#define FWUPG_FILE_OPEN_FAILED                  159 // file open failed.
#define FWUPG_UPGRADE_PHY_FW_ERROR              160 // Failed to upgrade PHY firmware.
#define FWUPG_INTERNAL_DATA_ERROR               161 // internal data error.
#define FWUPG_DEVICE_IS_NOT_UP                  162 // The device is not up and running.
#define FWUPG_LOW_SYSTEM_RESOURCES              163 // IOCTL failed due to low  system resources.
#define FWUPG_MBI_IMAGE_CHKSUM_FAILED           164 // MBI image file checksum failure
#define FWUPG_INVALID_VPD_IMAGE                 165 // Invalid VPD image in NVM
#define FWUPG_NVM_FILE_READ_ONLY                166 // Firmwares are readonly (i.e Firmware in Lockdown mode)

7. Examples:
==============
    Note:  
    The 'restorenvram' and 'upgrade' commands shall perform successfully
    for the specified adapter meeting ALL the following conditions:
    1) The device information of the adapter matches that in the image file. 
    2) The adapter currently supports the requested target firmware. 


7.1  Command Line Mode Examples:
*******************************

        'lnxfwnx2' will enter interactive mode.

        'lnxfwnx2 upgrade -bc /tmp/new_bootcode /tmp/oldBoot' will upgrade 
    bootcode for the ONLY qualified adapter found.  The adapter parameter 
    can be omitted if ONLY ONE qualified adapter is found.

        'lnxfwnx2 001018001199 upgrade -mba b57mmbae.nic /backup/oldPXE.bin'
    will upgrade PXE for the adapter with MAC 00:10:18:00:11:99.

        'lnxfwnx2 001018001199 upgrade -F -ipmi impi55
    old_image' will upgrade IPMI for the adapter with the specified MAC.

        'lnxfwnx2 -all upgrade -ipmi pt5706h6.20 /backup/saveIPMI' will 
    upgrade for all the qualified BRCM 5706 adapters that currently 
    support IPMI. When multiple applicable adapters are present, the MAC 
    address of the adapter is appended to the backup NVRAM image parameter 
    filename
    
        'lnxfwnx2 -all upgrade -F -ump /tmp/NtX2Ump.bin backupUMP' will force a 
    downgrade for all the BRCM 5706/5708 adapters with existing UMP support.  
    When multiple applicable adapters are present, the MAC address of the 
    adapter is appended to the backup NVRAM image parameter filename.

        'lnxfwnx2 -all dir -mbi ql_mbi_7148.bin' will display the listing
    of firmwares in NVMRAM for all the adapters that are supported in MBI  
    and are currently present in the system.

        'lnxfwnx2 -all dir' will display the listing of firmware in NVMRAM for
    all the adapters that currently present in the system.
    
        'lnxfwnx2 -all crc -mbi ql_mbi_7148.bin' will perform the CRC check on 
    all the adapters that are supported in MBI and are currently present in the system.

        'lnxfwnx2 -all crc' will perform CRC check on all the adapters that are 
    currently present in the system.
    
        'lnxfwnx2 -all restorenvram "/tmp/backup.bin" config' will read a 
    complete NVRAM image from file 'backup.bin' and write the image to NVRAM 
    along with its configurations.  If 'config' parameter is left out, only 
    the image is written. This will only restore NVRAM images to those with 
    matching FW, with the exception to variations in version numbers.

        'lnxfwnx2 0010181a1b1c cfg -mac 0010189d9e9f' will configure the 
    selected adapter whose current MAC address is 00:10:18:1a:1b:1c to be the 
    new MAC address 00:10:18:9d:9e:9f.

        'lnxfwnx2 0010189a9b9c cfg -ipmi 1' will enable ipmi firmware if the 
    ipmi firmware is present in the selected adapter whose current MAC address 
    is 00:10:18:9a:9b:9c.

        'lnxfwnx2 0010189a9b9c reset' will reset the selected adapter whose current
    MAC address is 00:10:18:9a:9b:9c.

        'lnxfwnx2 xml xml_name' will read the firmware versions from NVMRAM and export
    to XML.

        'lnxfwnx2 xml xml_name mbi_file' will read the firmware versions from given MBI
     file and export to XML.

7.2  Interactive Mode Examples:
*******************************

        'help' will display a list and descriptions of available commands.

        'q' will exit the utility.

        'dev' will display a list of upgradeable devices.

        'dev 0' will select device 0.

        'dir' will display a listing of the firmware programmed in NVRAM.

        'crc' will check the integrity of the NVRAM CRC.
 
        'dumpnvram /backup.bin' saves the dump file to the specified file.
    
        'restorenvram "/tmp_dir/backup.bin" config mac' 
    will include all configurations including the MAC address.  In order 
    to verify the MAC address was configured, exiting the program will be 
    necessary followed by either disabling and enabling the adapter or 
    rebooting the system.
    
        'upgrade -bc ee5706c3.19 backup5706.bin' will upgrade the boot code 
    for a BRCM 5706 adapter.

        'version' will display the version of Firmware Upgrade utility. 

        '-w 1' will enable the WOL setting on the current adapter.

        'cfg -mac 0010181a2b3c" will configure MAC address for the selected
    qualified adapter.

        'cfg -ump 0' will disable ump firmware if the ump firmware is present
    in the selected adapter.

        'cfg -show sriov' will display current setting of SRIOV in the selected 
    adapter.

        'cfg -show vf_per_pf' will display current setting of number of VF per PF
    in the selected adapter.


8. Known Limitations:
=====================

  1.  The read/write NVRAM operations and all other commands requiring NVRAM access are unable
      to perform correctly on Red Hat EL3.0 with kernel versions prior to 2.4.23.

        Due to a limitation in kernel versions prior to 2.4.23, older
        Linux distributions including Red Hat EL 3.0 may cause "firmware upgrade tool"
        not function with an error code 58.
        This problem is seen on 32-bit and 64-bit platforms with 57xx 
        family NICs loaded with tg3 driver (version >= 3.37) and 5706 
        family NICs loaded with bnx2 driver.
  
  2.  Known issue for BCM5709-based adapter:
      **************************************
      After this software is used to upgrade the firmware (including Bootcode,
      IPMI, UMP, iSCSI boot... ) in the NVRAM, the system has to be rebooted
      for the new firmware to become effective.
      The commands that require a reboot after exiting the software are
      "upgrade", "prg", and "restorenvram".

  3.  Known issue for E3 adapters running inbox drivers:
      **************************************
	  Some of the most recent kernels (for example in SLES15/SLES15.1) has a security feature to prevent 
	  user space access to physical memory above 1MB (IIRC). Due to which "firmmare upgrade tool"
	  may not function properly. 
	  There are couple of workaround:
	  1. At boot time: Add iomem=relaxed in kernel command line during boot time.
	  2. update grub.cfg file: 
	    2.1 add iomem=relaxed at the end for GRUB_CMDLINE_LINUX_DEFAULT parameter in file 
		/etc/default/grub.cfg (based on the distro, location of grub.cfg may vary)
		2.2 run cmd grub2-mkconfig -o /boot/grub2/grub.cfg
		2.3 reboot the server to take effect
      3. To avoid the issue or extra kernel param use the latest OOB drivers.

      Note: "iomem=relaxed" workaround will not work if Secure Boot is enabled. 
             Disable Secure Boot before updating the firmware when using "iomem=relaxed" workaround.
  
  4. "Grc Attn" and "qed_int_attentions" messages are observed while updating firmware on SLES15
      Issue is seen if qede driver 8.24.xx is installed on the SLES15 system. 
      The issue is seen when registers are accessed using ELBI method.      
      To resolve this issue please install updated out-of-box qede driver 8.37.xx or above on SLES15 
      where registers are accessed using debugfs interface.
      
  5.  Recent OS distro SLES15 SP2 when booted in secure boot mode does not allow user space applications 
      to access the debugfs nodes, due to which "firmware upgrade tool" may not function properly 
      so please disable secure Boot mode before updating the firmware.

  
9. Third Party Software License:
================================

Portions of this software contain third party code subject to the following conditions:

Tcl/Tk License Terms:
---------------------

/* This software is copyrighted by the Regents of the University of California, 
 * Sun Microsystems, Inc., Scriptics Corporation, and other parties. The following 
 * terms apply to all files associated with the software unless explicitly disclaimed 
 * in individual files.
 * 
 * The authors hereby grant permission to use, copy, modify, distribute, and license 
 * this software and its documentation for any purpose, provided that existing copyright 
 * notices are retained in all copies and that this notice is included verbatim in any 
 * distributions. No written agreement, license, or royalty fee is required for any of 
 * the authorized uses. Modifications to this software may be copyrighted by their authors 
 * and need not follow the licensing terms described here, provided that the new terms 
 * are clearly indicated on the first page of each file where they apply.
 * 
 * IN NO EVENT SHALL THE AUTHORS OR DISTRIBUTORS BE LIABLE TO ANY PARTY FOR DIRECT, 
 * INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OF 
 * THIS SOFTWARE, ITS DOCUMENTATION, OR ANY DERIVATIVES THEREOF, EVEN IF THE AUTHORS 
 * HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE AUTHORS AND DISTRIBUTORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, 
 * BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT. THIS SOFTWARE IS PROVIDED ON AN "AS IS" 
 * BASIS, AND THE AUTHORS AND DISTRIBUTORS HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, 
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 * 
 * GOVERNMENT USE: If you are acquiring this software on behalf of the U.S. government, 
 * the Government shall have only "Restricted Rights" in the software and related 
 * documentation as defined in the Federal Acquisition Regulations (FARs) in Clause 
 * 52.227.19 (c) (2). If you are acquiring the software on behalf of the Department of Defense, 
 * the software shall be classified as "Commercial Computer Software" and the Government 
 * shall have only "Restricted Rights" as defined in Clause 252.227-7013 (c) (1) of DFARs. 
 * Notwithstanding the foregoing, the authors grant the U.S. Government and others acting 
 * in its behalf permission to use and distribute the software in accordance with the terms 
 * specified in this license. 
 */


License of Libedit library:
---------------------------
/*-
* Copyright (c) 1992, 1993
*    The Regents of the University of California.  All rights reserved.
*
* This code is derived from software contributed to Berkeley by
* Christos Zoulas of Cornell University.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1. Redistributions of source code must retain the above copyright
*    notice, this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the following disclaimer in the
*    documentation and/or other materials provided with the distribution.
* 3. Neither the name of the University nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
* OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
* SUCH DAMAGE.
*
*/

